from django.shortcuts import render
from django.views.generic import FormView
from .models import EmpForm
# Create your views here.
def home(request):
    return render(request,'home.html')

class add_emp(FormView):
    form_class=EmpForm
    template_name='addemp.html'

